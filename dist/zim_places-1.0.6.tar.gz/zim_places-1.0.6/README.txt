This is a python package that allows you to search for cities, provinces, and districts in Zimbabwe.Zimbabwe is split into eight provinces and two cities that are designated as provincial capitals.
Districts are organized into 59 provinces.Wards are organized into 1,200 districts.Visit the project homepage for further information on how to use the package.

To can install the zim-places:

    pip install zim-places

To use zim-places package:

    import zim-places as zm

    #to get cities:

    zm.cities()

    #to get provinces

    zm.provinces()

    #to get wards

    zm.wards()

    #to get districts

    zm.districts()

